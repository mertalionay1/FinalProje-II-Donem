package com.mertali.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
